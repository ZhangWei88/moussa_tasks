const { expose } = require('threads/worker')
const { generateLuaForScenario, generateLua, generateLuaForRoute, generateLuaForInbound, generateLuaForClickToCall, generateFailLua, generateLuaForBlockedCalls, generateXmlForLua, formatLua, getDialingPlanRoutes  } = require('./dialing-plan-helper')

expose({
    generateLuaForScenario,
    generateLua,
    generateLuaForRoute,
    generateLuaForInbound,
    generateLuaForClickToCall,
    generateFailLua,
    generateLuaForBlockedCalls,
    generateXmlForLua,

    formatLua,

    getDialingPlanRoutes
})