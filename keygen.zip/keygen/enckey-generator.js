import crypto from 'crypto';
import fs from 'fs';

let encOptions = {
    "modulusLength": 4096, 
    "publicKeyEncoding": {
        "type": "spki", 
        "format": "pem"
    }, 
    "privateKeyEncoding": {
        "type": "pkcs8", 
        "format": "pem", 
        "cipher": "aes-256-cbc", 
        "passphrase": "6$2#jN322xX*cWrYaGDQ$uFUbV3XSKfn*TaM4mYQtXs69YEy7Q7qkDy@@c%SH3qh58%4xD4YTq4#Uc$w@J4hr9jM!k!X7Ws5Sud97HC%2^Xf6X&%V3vs86&aJj^4RP3b7WYywr%*Hpurb3EK3k5G%Dw54ZC7u@a7"
    }
};

let keyPair = crypto.generateKeyPairSync("rsa", encOptions);
fs.writeFileSync("private.pem", keyPair.privateKey);
fs.writeFileSync("public.pem", keyPair.publicKey);