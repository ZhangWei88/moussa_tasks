import fs from 'fs';
import crypto from 'crypto';

function encryptLicense(plainTextBase64, machineId) {
    // 64-byte salt
    const salt = crypto.randomBytes(64);

    // Derive AES key
    const key = crypto.pbkdf2Sync(
        machineId,
        salt,
        100000,
        32,
        "sha512"
    );

    // 16-byte IV for GCM
    const iv = crypto.randomBytes(16);

    const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);

    const encrypted = Buffer.concat([
        cipher.update(plainTextBase64, "utf8"),
        cipher.final()
    ]);

    const authTag = cipher.getAuthTag();

    // Final buffer layout must match decryptLicense()
    const finalBuffer = Buffer.concat([
        salt,
        iv,
        authTag,
        encrypted
    ]);

    return finalBuffer.toString("hex");
}

function encodeLicense(filename, licenseObj) {
    // 1. JSON → string
    const jsonStr = JSON.stringify(licenseObj.license);

    // 2. RSA private encrypt (reverse of publicDecrypt)
    const encOptions = {
        key: "-----BEGIN ENCRYPTED PRIVATE KEY-----\nMIIJrTBXBgkqhkiG9w0BBQ0wSjApBgkqhkiG9w0BBQwwHAQIHZifKfvQA2sCAggA\nMAwGCCqGSIb3DQIJBQAwHQYJYIZIAWUDBAEqBBD1GAolz8Lqw+aL+eFoRT5uBIIJ\nUBkn6Dt1dDZpNboLV0KTVl3uZQXA+/WIpAqESR486M0A8PZtmXFIL9M9kQalz7O4\n7tySH4c24KR0bIDNkQ4UF39ofJRE+uNM4Wb111laeujG6Vot7Huqf7DuOTeFGouu\nS4ylfI08r/ArOWaxAmXr/EESSBcXa8x/tglCDwYJy62bKJTLqHCxQbhkJHazb+Ca\nX+uIWB40zCyOPV9EHMRQPBbGxDMcyLPRli9mbj/3MBFV+0JbwbOx2aKntXiH8Ytu\nuoMDgIDm5N+z9DRZgetb2rCP1Iyz0CkB3SS6p/YKuLd8uzOw/uG0biXltLO0adbe\nbYYlPSA/0fi9GfgDmGcziU+VFU2ZiDGSeMBxCmwSJUtZAgdYPgd0/jjYJ6VuJnb6\n5Pi1aXywsM8X7T/PnesnWqCL/fTOb8cbjoeY5PI6ExAFk+Q/3uxYzsbB/EEI99Hi\ncyhzBqc+DDfeBF9LzPwt4/6UeF5bKxz1MCcYDqByXk3yBp9zoa4HXFnqQ8qMD7tw\nw3t+NHRWpDg6YuEApjmgJ7z82xgbTtsbApX+YIRPgbg9dsH0Xau2ZwgDmxlXSQ3b\nMp7sLmrytcGm6DAcavKT/V7OtSX6ZZFc9/jqym608vJcl4Z9+e/imDGSJG4maZVk\n+9VWKlUDgRMYwwZT+7xO/3HqIWvGhyVVXI8g5Ta918ctflK3MvvyWcuH6iqN7Ceq\noQWI6Z7d30GEsIKpzSojkU7SgEuBzdr3lf01w92PltnsTIMLUR9OIKPtHYC8wFAW\nVH71rO/17JmdefvaSmOyiK1Pjm0nUP/kzMPo1RWEWD1tDHJEYydR8iOcepjlMsTf\nWArUMJLtdzkdIhNaEwuM1gZideD2dzcw0dfQVwjroAckfOdgfBamJMmJCqNwyZSQ\nzF1khNTbHF+PmjGpzvL+ctNkOPsuE3zwxJEitVe+dBT9rQQmTD5T7MpQNvQT9VMC\nTU84gRhXsSVtvHRoCF1P5cS8z9vUoKIjhJxoPtsDyUQ6JvnQFnngq9Ad9PT24HoZ\nV+BzXPWhq2bfCDlyb82MsH2z39eRQy6RqHO8LHncuzphyzGcJX05/a8DrWMSv6wn\n8RP5alHokmRZNFooe0Fvosr3YD4yblVkJuIBRcaYeQ3bcAOL6zEOcb9uv34fCT0V\nNaE2QePmtw4EfgqLEejy3Xko+SZODb/Ou2CgY/96IlMRwoOrEyhPRgMoKNie+85a\nqdd6IMW6rbCFu9O/N8CKW5SCxT48B0DyemQ6OIMhxExAkzigZ0v+U0c5kJYI8SfO\nXEc6pDxhnXHk+UUwXksswN5LwA+lAJmXCTfvm+xhYIShMGUVTSmy27Ty0f3rufy8\nT0EoDF7j3nzEwhAiP8QaOdcfr2KamlqQkBRgkVdOPZ6sac3UkdfScPKOAqcLebX9\nGNuBCocW6WTo3tZ3mCz2JMcH3FGZZYSJDgGIbD53TbvjD2kFnjFadJec1Q/cDlp3\n4uoFvzEFjvnq5XRYMDmgHtHhJCEWpnjpEgZKu41ZPBthSVkGGQL9CvHxovH8PFRO\nBFlRvy7R4wBptMVvwQ7vyk3E1zstl78RVkqXlpUQKXVCH/1XUNbEPYwChcn1Viuc\nCKVzBDJoi6v0L4JHxX3LeSjekxTpb+ut3Qqu2La21g065XHBX+DRVSngICNgLWrn\nTke67HgSAmFZClP0t6xKD207pneY8DBwjRT7NjLo5TL6U5dEAWMWPRjWgZFD1B8Y\nuwHzfsQfBONwU1Mhk/uVHb1MckmbHLo3EOJCGY/yHttJmmSm1RRcBjH/MvqoHmnl\nBX8uVizArZ/az6kMpfGKgrZCpdCElsNyydEYe5vRtX0L5jRNCXIYiSAu+MMvsnNn\nwZFKTt9w4Q4I48q7MbRqSx8Am5WlHvZ2bHhm4fsoopON/++Xwz2TDGP5EhLIsv0M\nFNRg3kAO3taVK29KvEZZlSekPJ5U1cwwkpSb3IYSbmg0vwudBq9uX955PyQbvz/R\nyF9IBYlcprQOWzDg9mINB+qCAWNdV6d0UJmPq7PwD8Do5W6NKsEhQhOGG1OTi7qf\nRWqlil1JWPT1846GrBVhLoT5Ol43W/CCdXL9AFs7UPlp8uqXvJ/7Ck2HihpGJAW6\nSe2191kFjCCl0FplUo7geZgTbWRSV7WXy+eNXUOH7y762QPbZSjvuLFs20t5jgxt\ndo8cNYNiyUt5HMlAEhQEnQooeAJmZBMXqVVCizpz5eS4264s5wiCHIXznTULsXph\nYUvqwj+qwqYUKeWBcsbS92cDpRgx+TGQcU6VuBidbL5CNI0GMEYXAlvKdQB6S3Ec\n4cZhsQUjR2u0dLYS5R7/o63kqRJ0Vsywa5fu9Ny62Bcx+AkfS8DQ7xBXUd/6Rwe7\nythMRYW1YihbR1zdLXfep/XmcMIL5/GZVduC+eFTIWJUOyJlT2Th+T0Bw/rihLls\nm3pVM8q19utjnu5vmdQ3PIpvzF3jIEgEeixkHWsfeb4w56a9W3HvNFO3B1qoBkGd\n7K/7O1BhmYTwfkFbwCos7tak0KnYJLeEFyU+BFPO4bIaEdt2M0AkZ8thZd3971Hz\nMgLrH5t+2K7XEIsGismIeo0Y/WgBfaTGwdrDd/fHMFSlFltQJ8BYIiyacPN5I0EX\nqIwbbZ0ARc10kmwMNak81QQxwGcXb3uLDJsCmQTh0OxKx3RGVHzGqvlfq1FQG7zo\n8V+HStuZAGGf+B1Q82j1jZRwohdBg2PvFJ3yDKNiyZ3+Tltv+K5s5G1gbWZ8EbX7\nDM6/M6RhIcfjPnJkJ+AYdFhPoiW8CLv4glWvCsj3+AWNZw/CAcyBtL5SIWbKUp/S\nyW14OgUIwwX2KGjk+6DHBErkJ/8eYB25jLVUQ3gVtu089yWHlQmE+PEKEWtWFxE+\n5RxijlqHNd6nknq7vAwjDJW+i/FgLzqLcIayxNHA2rT5IMENopJuI3Nmr/531mBp\n//dv3o3atxta9cfxcqP67uIfTAFl0xEHGQYiqwBUe5bL4WRGUHqUoE7k+2+zuDGY\nkEXXXDEQ8uoNE3uqUfPRZ9cJJVhsr7xzouHu+duS7YF2RZ3jZnvQhX5VOGttUhm/\nuqg8XyafD3ZBmzT/t/UZbPzaXqCDOeCxDlTJfsvCroFOBgCSX8O4I04ti7tp0DVR\n6BqfCTcJZeceeE1Uu0UuSzIVourpmXoC3sLJFk8Ta3TA\n-----END ENCRYPTED PRIVATE KEY-----",
        passphrase: "6$2#jN322xX*cWrYaGDQ$uFUbV3XSKfn*TaM4mYQtXs69YEy7Q7qkDy@@c%SH3qh58%4xD4YTq4#Uc$w@J4hr9jM!k!X7Ws5Sud97HC%2^Xf6X&%V3vs86&aJj^4RP3b7WYywr%*Hpurb3EK3k5G%Dw54ZC7u@a7"
    };

    const encryptedRSA = crypto.privateEncrypt(
        encOptions,
        Buffer.from(jsonStr, "utf8")
    );

    // 3. Base64 encode
    const base64Payload = encryptedRSA.toString("base64");

    // 4. AES encrypt
    const encryptedHex = encryptLicense(base64Payload, licenseObj.machineId);

    // 5. Write to file
    fs.writeFileSync(filename, encryptedHex);
}

let licenseData = fs.readFileSync('./license-data.json');
let strLicenseData = licenseData.toString("utf-8");
let licenseObj = JSON.parse(strLicenseData);

encodeLicense(
    "CORE.license",
    licenseObj
);